package ca.superroute.slocker;

import ca.superroute.slocker.generated.GeneratedApi;
import ca.superroute.slocker.generated.Operations;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** A client of the Superroute partner locker delivery API. Thread safe once the token is set. */
public class Client extends GeneratedApi {
    public static final String VERSION = "0.2.1";
    public static final String DEFAULT_BASE_URL = "https://api.superroute.ca";
    private static final Set<Integer> RETRY_STATUSES = new HashSet<>(Arrays.asList(408, 425, 429, 500, 502, 503, 504));
    private static final int MAX_RETRY_AFTER = 60;

    /** Waits between retries. */
    public interface Sleeper {
        void sleep(double seconds) throws InterruptedException;
    }

    private volatile String token;
    private volatile Long providerId;
    private final String baseUrl;
    private final int maxRetries;
    private final Transport transport;
    private final Sleeper sleeper;
    private final String userAgent;

    private Client(Builder b) {
        this.token = b.token;
        this.providerId = b.providerId;
        this.baseUrl = b.baseUrl.replaceAll("/+$", "");
        this.maxRetries = Math.max(0, b.maxRetries);
        this.transport = b.transport != null ? b.transport : HttpTransports.defaultTransport(b.timeout);
        this.sleeper = b.sleeper != null ? b.sleeper : seconds -> Thread.sleep((long) (seconds * 1000));
        this.userAgent = b.userAgent != null ? b.userAgent : "slocker-java/" + VERSION;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private String token;
        private Long providerId;
        private String baseUrl = DEFAULT_BASE_URL;
        private int maxRetries = 2;
        private Duration timeout = Duration.ofSeconds(30);
        private Transport transport;
        private Sleeper sleeper;
        private String userAgent;

        /** An access token (POST /api/v1/user/login); or sign in with {@link Client#login}. */
        public Builder token(String token) { this.token = token; return this; }
        /** The third-party delivery provider to act as (X-Third-Party-Provider-Id). */
        public Builder providerId(Long providerId) { this.providerId = providerId; return this; }
        public Builder baseUrl(String baseUrl) { this.baseUrl = baseUrl; return this; }
        /** How often a repeatable call (reads, deletes, creates with an idempotency key) is repeated. */
        public Builder maxRetries(int maxRetries) { this.maxRetries = maxRetries; return this; }
        public Builder timeout(Duration timeout) { this.timeout = timeout; return this; }
        public Builder transport(Transport transport) { this.transport = transport; return this; }
        public Builder sleeper(Sleeper sleeper) { this.sleeper = sleeper; return this; }
        public Builder userAgent(String userAgent) { this.userAgent = userAgent; return this; }
        public Client build() { return new Client(this); }
    }

    public String token() { return token; }
    public void token(String token) { this.token = token; }
    public Long providerId() { return providerId; }
    public void providerId(Long providerId) { this.providerId = providerId; }

    /** Signs in (POST /api/v1/user/login) and keeps the access token. businessId may be null. */
    public Object login(String email, String password, Long businessId) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("email", email);
        body.put("password", password);
        if (businessId != null) {
            body.put("business_id", businessId);
        }
        return takeToken(send("POST", "/v1/user/login", body, false, false, null, null));
    }

    /** A new token for the current one (POST /api/v1/user/refresh-token). */
    public Object refreshToken() {
        return takeToken(send("POST", "/v1/user/refresh-token", null, false, true, null, null));
    }

    /** A new token, the current one valid for the grace period (POST /api/v1/user/rotate-token); null for the default. */
    public Object rotateToken(Integer gracePeriodMinutes) {
        Map<String, Object> body = null;
        if (gracePeriodMinutes != null) {
            body = new LinkedHashMap<>();
            body.put("grace_period_minutes", gracePeriodMinutes);
        }
        return takeToken(send("POST", "/v1/user/rotate-token", body, false, true, null, null));
    }

    /** Revokes the token (GET /api/v1/user/logout) and forgets it. */
    public Object logout() {
        Object result = send("GET", "/v1/user/logout", null, false, true, null, null);
        token = null;
        return result;
    }

    private Object takeToken(Object result) {
        if (result instanceof Map && ((Map<?, ?>) result).get("access_token") instanceof String) {
            token = (String) ((Map<?, ?>) result).get("access_token");
        }
        return result;
    }

    /** Runs one operation by name. Answers the response body as parsed JSON. */
    @Override
    public Object call(String operation, Params params) {
        Params p = params == null ? Params.create() : params;
        Operation op = Operations.ALL.get(operation);
        if (op == null) {
            throw invalid("Unknown operation " + operation);
        }
        String path = op.path;
        for (String name : op.pathParams) {
            Object v = p.get(name);
            if (v == null || "".equals(v)) {
                throw invalid(operation + " needs " + name);
            }
            path = path.replace("{" + name + "}", encode(text(v)));
        }
        List<String> query = new ArrayList<>();
        for (String name : op.query) {
            Object v = p.get(name);
            if (v != null) {
                query.add(name + "=" + encode(text(v)));
            }
        }
        if (!query.isEmpty()) {
            path += "?" + String.join("&", query);
        }
        String key = null;
        if (op.idempotent) {
            key = p.idempotencyKey() != null && !p.idempotencyKey().isEmpty() ? p.idempotencyKey() : UUID.randomUUID().toString();
        }
        Long provider = p.providerId() != null ? p.providerId() : providerId;
        return send(op.method, path, op.body ? p.body() : null, op.retry, true, key, provider);
    }

    private static SLockerException invalid(String message) {
        return new SLockerException(0, "INVALID_ARGUMENT", message, null, null, null, null);
    }

    private Object send(String method, String path, Object body, boolean retry, boolean auth, String key, Long provider) {
        Map<String, String> headers = new LinkedHashMap<>();
        headers.put("Accept", "application/json");
        headers.put("User-Agent", userAgent);
        String t = token;
        if (auth && t != null && !t.isEmpty()) {
            headers.put("Authorization", "Bearer " + t);
        }
        if (provider != null) {
            headers.put("X-Third-Party-Provider-Id", provider.toString());
        }
        if (key != null) {
            headers.put("Idempotency-Key", key);
        }
        byte[] data = null;
        if (body != null) {
            headers.put("Content-Type", "application/json");
            data = Json.stringify(body).getBytes(StandardCharsets.UTF_8);
        }
        String url = baseUrl + "/api" + path;
        for (int attempt = 0; ; attempt++) {
            Transport.Response res;
            try {
                res = transport.send(new Transport.Request(method, url, new LinkedHashMap<>(headers), data));
            } catch (IOException | RuntimeException e) {
                if (retry && attempt < maxRetries) {
                    pause(backoff(attempt));
                    continue;
                }
                String m = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                throw new SLockerException(0, "NETWORK_ERROR", m, null, null, null, e);
            }
            Object parsed = parse(res.body);
            if (res.status >= 200 && res.status < 300) {
                return parsed;
            }
            if (retry && RETRY_STATUSES.contains(res.status) && attempt < maxRetries) {
                Integer ra = retryAfter(res.headers, null);
                pause(ra != null ? Math.min(ra, MAX_RETRY_AFTER) : backoff(attempt));
                continue;
            }
            throw errorFrom(res.status, res.headers, parsed);
        }
    }

    private void pause(double seconds) {
        try {
            sleeper.sleep(seconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new SLockerException(0, "NETWORK_ERROR", "interrupted", null, null, null, e);
        }
    }

    static SLockerException errorFrom(int status, Map<String, String> headers, Object body) {
        Map<?, ?> data = body instanceof Map ? (Map<?, ?>) body : new LinkedHashMap<>();
        Object c = data.get("code");
        String code = c instanceof String && !((String) c).isEmpty() ? (String) c : status == 401 ? "UNAUTHENTICATED" : "HTTP_" + status;
        Object m = data.get("message");
        String message = m instanceof String ? (String) m : "HTTP " + status;
        return new SLockerException(status, code, message, data.get("errors"), retryAfter(headers, body), body, null);
    }

    static Integer retryAfter(Map<String, String> headers, Object body) {
        if (headers != null) {
            for (Map.Entry<String, String> h : headers.entrySet()) {
                if (h.getKey() != null && h.getKey().equalsIgnoreCase("Retry-After") && h.getValue() != null && h.getValue().trim().matches("\\d+")) {
                    return Integer.parseInt(h.getValue().trim());
                }
            }
        }
        if (body instanceof Map && ((Map<?, ?>) body).get("errors") instanceof Map) {
            Object s = ((Map<?, ?>) ((Map<?, ?>) body).get("errors")).get("retry_after_seconds");
            if (s instanceof Long || s instanceof Integer) {
                return ((Number) s).intValue();
            }
        }
        return null;
    }

    private static Object parse(byte[] raw) {
        if (raw == null || raw.length == 0) {
            return null;
        }
        String text = new String(raw, StandardCharsets.UTF_8);
        try {
            return Json.parse(text);
        } catch (IllegalArgumentException e) {
            return text;
        }
    }

    /** A query or path value as the server reads it: booleans as 1 / 0, whole numbers without a decimal point. */
    static String text(Object v) {
        if (v instanceof Boolean) {
            return (Boolean) v ? "1" : "0";
        }
        if (v instanceof Double || v instanceof Float) {
            double d = ((Number) v).doubleValue();
            if (d == Math.rint(d) && Math.abs(d) < 1e15) {
                return Long.toString((long) d);
            }
            return new java.math.BigDecimal(Double.toString(d)).stripTrailingZeros().toPlainString();
        }
        return String.valueOf(v);
    }

    static String encode(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8").replace("+", "%20").replace("*", "%2A").replace("%7E", "~");
        } catch (java.io.UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
    }

    private static double backoff(int attempt) {
        return Math.min(8, 0.5 * Math.pow(2, attempt)) * (0.5 + ThreadLocalRandom.current().nextDouble() / 2);
    }
}
