package ca.superroute.slocker;

import java.util.List;

/** One operation of the partner locker API, as generated from the spec. */
public final class Operation {
    public final String id;
    public final String method;
    public final String path;
    public final List<String> pathParams;
    public final List<String> query;
    public final boolean body;
    public final boolean bodyRequired;
    public final boolean idempotent;
    public final boolean retry;

    public Operation(String id, String method, String path, List<String> pathParams, List<String> query, boolean body,
                     boolean bodyRequired, boolean idempotent, boolean retry) {
        this.id = id;
        this.method = method;
        this.path = path;
        this.pathParams = pathParams;
        this.query = query;
        this.body = body;
        this.bodyRequired = bodyRequired;
        this.idempotent = idempotent;
        this.retry = retry;
    }
}
