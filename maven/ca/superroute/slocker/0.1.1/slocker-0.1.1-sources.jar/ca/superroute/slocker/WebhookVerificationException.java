package ca.superroute.slocker;

/**
 * A webhook that must be refused. {@link #reason} is one of MISSING_HEADER, INVALID_TIMESTAMP,
 * TIMESTAMP_OUT_OF_TOLERANCE, DIGEST_MISMATCH, SIGNATURE_MISMATCH or INVALID_PAYLOAD.
 */
public final class WebhookVerificationException extends Exception {
    public final String reason;

    public WebhookVerificationException(String reason) {
        super(reason);
        this.reason = reason;
    }
}
