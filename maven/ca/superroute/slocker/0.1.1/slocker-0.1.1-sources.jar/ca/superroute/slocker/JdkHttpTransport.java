package ca.superroute.slocker;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** java.net.http (Java 11+). Loaded only where that module exists. */
final class JdkHttpTransport implements Transport {
    private static final Set<String> RESTRICTED = Set.of("connection", "content-length", "expect", "host", "upgrade");
    private final HttpClient client;
    private final Duration timeout;

    JdkHttpTransport(Duration timeout) {
        this.timeout = timeout;
        this.client = HttpClient.newBuilder().connectTimeout(timeout).followRedirects(HttpClient.Redirect.NEVER).build();
    }

    @Override
    public Response send(Request request) throws IOException {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(request.url)).timeout(timeout)
                .method(request.method, request.body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofByteArray(request.body));
        for (Map.Entry<String, String> h : request.headers.entrySet()) {
            if (!RESTRICTED.contains(h.getKey().toLowerCase())) {
                b.header(h.getKey(), h.getValue());
            }
        }
        try {
            HttpResponse<byte[]> res = client.send(b.build(), HttpResponse.BodyHandlers.ofByteArray());
            Map<String, String> headers = new LinkedHashMap<>();
            res.headers().map().forEach((k, v) -> {
                if (!v.isEmpty()) {
                    headers.put(k, v.get(0));
                }
            });
            return new Response(res.statusCode(), headers, res.body());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("interrupted", e);
        }
    }
}
