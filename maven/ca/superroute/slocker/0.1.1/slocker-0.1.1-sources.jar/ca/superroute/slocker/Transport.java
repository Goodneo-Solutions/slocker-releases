package ca.superroute.slocker;

import java.io.IOException;
import java.util.Map;

/** Sends one HTTP request. Throws IOException on a request that got no answer. */
public interface Transport {
    Response send(Request request) throws IOException;

    final class Request {
        public final String method;
        public final String url;
        public final Map<String, String> headers;
        /** UTF-8 JSON, or null. */
        public final byte[] body;

        public Request(String method, String url, Map<String, String> headers, byte[] body) {
            this.method = method;
            this.url = url;
            this.headers = headers;
            this.body = body;
        }
    }

    final class Response {
        public final int status;
        public final Map<String, String> headers;
        public final byte[] body;

        public Response(int status, Map<String, String> headers, byte[] body) {
            this.status = status;
            this.headers = headers;
            this.body = body;
        }
    }
}
