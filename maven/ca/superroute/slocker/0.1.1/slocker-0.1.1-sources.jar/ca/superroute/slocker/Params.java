package ca.superroute.slocker;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * An operation's parameters: path and query parameters by their spec names, the JSON body, the idempotency key and
 * the provider for this call.
 */
public final class Params {
    private final Map<String, Object> values = new LinkedHashMap<>();
    private Object body;
    private String idempotencyKey;
    private Long providerId;

    public static Params create() {
        return new Params();
    }

    /** Sets a path or query parameter; null leaves it out. */
    public Params put(String name, Object value) {
        if (value == null) {
            values.remove(name);
        } else {
            values.put(name, value);
        }
        return this;
    }

    /** The JSON body: a Map (objects), List, String, Number, Boolean or null. */
    public Params body(Object body) {
        this.body = body;
        return this;
    }

    /** Sent as Idempotency-Key where the operation takes one; one is made (and kept across retries) when left out. */
    public Params idempotencyKey(String key) {
        this.idempotencyKey = key;
        return this;
    }

    /** Overrides the client's provider for this call (X-Third-Party-Provider-Id). */
    public Params providerId(Long providerId) {
        this.providerId = providerId;
        return this;
    }

    public Object get(String name) {
        return values.get(name);
    }

    public Object body() {
        return body;
    }

    public String idempotencyKey() {
        return idempotencyKey;
    }

    public Long providerId() {
        return providerId;
    }

    public Params copy() {
        Params p = new Params();
        p.values.putAll(values);
        p.body = body;
        p.idempotencyKey = idempotencyKey;
        p.providerId = providerId;
        return p;
    }

    /** Params from a map with the spec names and the keys "body", "idempotencyKey" and "providerId". */
    public static Params fromMap(Map<String, ?> map) {
        Params p = new Params();
        for (Map.Entry<String, ?> e : map.entrySet()) {
            switch (e.getKey()) {
                case "body":
                    p.body = e.getValue();
                    break;
                case "idempotencyKey":
                    p.idempotencyKey = e.getValue() == null ? null : e.getValue().toString();
                    break;
                case "providerId":
                    p.providerId = e.getValue() == null ? null : ((Number) e.getValue()).longValue();
                    break;
                default:
                    p.put(e.getKey(), e.getValue());
            }
        }
        return p;
    }
}
