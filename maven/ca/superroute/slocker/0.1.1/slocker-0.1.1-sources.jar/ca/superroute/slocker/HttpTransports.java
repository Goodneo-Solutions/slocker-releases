package ca.superroute.slocker;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** The built-in transports. */
public final class HttpTransports {
    private HttpTransports() {}

    /** java.net.http on Java 11+, otherwise HttpURLConnection (Android). */
    public static Transport defaultTransport(Duration timeout) {
        try {
            Class.forName("java.net.http.HttpClient");
            return new JdkHttpTransport(timeout);
        } catch (ClassNotFoundException | LinkageError e) {
            return urlConnection(timeout);
        }
    }

    /**
     * HttpURLConnection, available everywhere including Android. It cannot send PATCH, so a PATCH goes as POST with
     * X-HTTP-Method-Override: PATCH, which the server honours.
     */
    public static Transport urlConnection(Duration timeout) {
        return request -> {
            HttpURLConnection c = (HttpURLConnection) new URL(request.url).openConnection();
            int ms = (int) timeout.toMillis();
            c.setConnectTimeout(ms);
            c.setReadTimeout(ms);
            c.setInstanceFollowRedirects(false);
            String method = request.method;
            if ("PATCH".equals(method)) {
                method = "POST";
                c.setRequestProperty("X-HTTP-Method-Override", "PATCH");
            }
            c.setRequestMethod(method);
            for (Map.Entry<String, String> h : request.headers.entrySet()) {
                c.setRequestProperty(h.getKey(), h.getValue());
            }
            if (request.body != null) {
                c.setDoOutput(true);
                try (OutputStream out = c.getOutputStream()) {
                    out.write(request.body);
                }
            }
            int status = c.getResponseCode();
            Map<String, String> headers = new LinkedHashMap<>();
            for (Map.Entry<String, List<String>> h : c.getHeaderFields().entrySet()) {
                if (h.getKey() != null && !h.getValue().isEmpty()) {
                    headers.put(h.getKey(), h.getValue().get(0));
                }
            }
            InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
            byte[] body = in == null ? new byte[0] : readAll(in);
            c.disconnect();
            return new Transport.Response(status, headers, body);
        };
    }

    static byte[] readAll(InputStream in) throws IOException {
        try (InputStream s = in) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = s.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }
}
