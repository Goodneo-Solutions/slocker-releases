package ca.superroute.slocker;

/**
 * A call that failed. Act on {@link #status} and {@link #code}, never on the message: status is the HTTP status (0
 * when no answer came back or the call never left), code the server's code (LOCKER_…), UNAUTHENTICATED,
 * HTTP_&lt;status&gt;, NETWORK_ERROR or INVALID_ARGUMENT.
 */
public final class SLockerException extends RuntimeException {
    public final int status;
    public final String code;
    public final String serverMessage;
    public final Object errors;
    public final Integer retryAfter;
    public final Object body;

    public SLockerException(int status, String code, String message, Object errors, Integer retryAfter, Object body, Throwable cause) {
        super(code + " (" + status + "): " + message, cause);
        this.status = status;
        this.code = code;
        this.serverMessage = message;
        this.errors = errors;
        this.retryAfter = retryAfter;
        this.body = body;
    }
}
