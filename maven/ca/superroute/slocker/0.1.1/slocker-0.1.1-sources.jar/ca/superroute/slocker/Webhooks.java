package ca.superroute.slocker;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/** Verifies the webhooks Superroute sends, and signs test requests the same way. */
public final class Webhooks {
    public static final int DEFAULT_TOLERANCE_SECONDS = 300;

    private Webhooks() {}

    /** {@link #verify(byte[], Map, List, int, Long)} with the default tolerance and the current time. */
    public static WebhookEvent verify(byte[] body, Map<String, String> headers, List<String> secrets) throws WebhookVerificationException {
        return verify(body, headers, secrets, DEFAULT_TOLERANCE_SECONDS, null);
    }

    /**
     * Checks a webhook request and answers its event. body must be the raw request body exactly as received; secrets
     * the endpoint's signing secret, or several during a rotation window. now is Unix seconds, null for the clock.
     */
    @SuppressWarnings("unchecked")
    public static WebhookEvent verify(byte[] body, Map<String, String> headers, List<String> secrets, int toleranceSeconds, Long now)
            throws WebhookVerificationException {
        Map<String, String> h = new LinkedHashMap<>();
        for (Map.Entry<String, String> e : headers.entrySet()) {
            if (e.getKey() != null && e.getValue() != null) {
                h.put(e.getKey().toLowerCase(java.util.Locale.ROOT), e.getValue());
            }
        }
        List<String> keys = new ArrayList<>();
        for (String s : secrets) {
            if (s != null && !s.isEmpty()) {
                keys.add(s);
            }
        }
        boolean nativeHeaders;
        if (present(h, "x-webhook-signature")) {
            for (String n : new String[] {"x-webhook-timestamp", "x-webhook-delivery-id", "x-webhook-content-digest", "x-webhook-signature"}) {
                if (!present(h, n)) {
                    throw new WebhookVerificationException("MISSING_HEADER");
                }
            }
            String ts = h.get("x-webhook-timestamp");
            timestamp(ts, toleranceSeconds, now);
            if (!equal(h.get("x-webhook-content-digest"), "sha256=" + b64(sha256(body)))) {
                throw new WebhookVerificationException("DIGEST_MISMATCH");
            }
            byte[] message = concat((ts + "\n" + h.get("x-webhook-delivery-id") + "\n").getBytes(StandardCharsets.UTF_8), body);
            boolean matched = false;
            for (String s : keys) {
                matched |= equal(h.get("x-webhook-signature"), "v1=" + hmac(s, message));
            }
            if (!matched) {
                throw new WebhookVerificationException("SIGNATURE_MISMATCH");
            }
            nativeHeaders = true;
        } else if (present(h, "webhook-signature")) {
            if (!present(h, "webhook-id") || !present(h, "webhook-timestamp")) {
                throw new WebhookVerificationException("MISSING_HEADER");
            }
            String ts = h.get("webhook-timestamp");
            timestamp(ts, toleranceSeconds, now);
            byte[] message = concat((h.get("webhook-id") + "." + ts + ".").getBytes(StandardCharsets.UTF_8), body);
            boolean matched = false;
            for (String s : keys) {
                String expected = "v1," + hmac(s, message);
                for (String r : h.get("webhook-signature").split(" ")) {
                    if (!r.isEmpty()) {
                        matched |= equal(r, expected);
                    }
                }
            }
            if (!matched) {
                throw new WebhookVerificationException("SIGNATURE_MISMATCH");
            }
            nativeHeaders = false;
        } else {
            throw new WebhookVerificationException("MISSING_HEADER");
        }

        Object parsed;
        try {
            parsed = Json.parse(new String(body, StandardCharsets.UTF_8));
        } catch (IllegalArgumentException e) {
            throw new WebhookVerificationException("INVALID_PAYLOAD");
        }
        if (!(parsed instanceof Map)) {
            throw new WebhookVerificationException("INVALID_PAYLOAD");
        }
        Map<String, Object> payload = (Map<String, Object>) parsed;
        if (payload.containsKey("specversion") && payload.get("data") instanceof Map) {
            payload = (Map<String, Object>) payload.get("data");
        }
        if (!(payload.get("event_type") instanceof String)) {
            throw new WebhookVerificationException("INVALID_PAYLOAD");
        }
        boolean testHeader = "1".equals(h.get("x-webhook-test"));
        boolean livemode = payload.get("livemode") instanceof Boolean ? (Boolean) payload.get("livemode") : !testHeader;
        String eventId = payload.get("event_id") instanceof String ? (String) payload.get("event_id")
                : h.get("x-webhook-id") != null ? h.get("x-webhook-id") : h.get("webhook-id");
        Map<String, Object> data = payload.get("data") instanceof Map ? (Map<String, Object>) payload.get("data") : new LinkedHashMap<>();
        return new WebhookEvent(eventId, (String) payload.get("event_type"), livemode, testHeader || !livemode,
                payload.get("occurred_at") instanceof String ? (String) payload.get("occurred_at") : null, data, payload,
                nativeHeaders ? h.get("x-webhook-delivery-id") : null, nativeHeaders ? h.get("x-webhook-key-id") : null, h);
    }

    /**
     * The headers Superroute would send with body: for testing your own webhook receiver. timestamp, deliveryId,
     * keyId and eventId may be null.
     */
    public static Map<String, String> sign(String secret, byte[] body, Long timestamp, String deliveryId, String keyId, String eventId, boolean test) {
        String ts = Long.toString(timestamp != null ? timestamp : System.currentTimeMillis() / 1000);
        String did = deliveryId != null ? deliveryId : UUID.randomUUID().toString();
        Map<String, String> h = new LinkedHashMap<>();
        h.put("Content-Type", "application/json");
        h.put("X-Webhook-Delivery-Id", did);
        h.put("X-Webhook-Timestamp", ts);
        h.put("X-Webhook-Content-Digest", "sha256=" + b64(sha256(body)));
        h.put("X-Webhook-Signature", "v1=" + hmac(secret, concat((ts + "\n" + did + "\n").getBytes(StandardCharsets.UTF_8), body)));
        if (eventId != null) {
            h.put("X-Webhook-Id", eventId);
        }
        if (keyId != null) {
            h.put("X-Webhook-Key-Id", keyId);
        }
        if (test) {
            h.put("X-Webhook-Test", "1");
        }
        return h;
    }

    private static boolean present(Map<String, String> h, String name) {
        String v = h.get(name);
        return v != null && !v.isEmpty();
    }

    private static void timestamp(String value, int tolerance, Long now) throws WebhookVerificationException {
        if (!value.matches("[0-9]{1,12}")) {
            throw new WebhookVerificationException("INVALID_TIMESTAMP");
        }
        long current = now != null ? now : System.currentTimeMillis() / 1000;
        if (Math.abs(current - Long.parseLong(value)) > tolerance) {
            throw new WebhookVerificationException("TIMESTAMP_OUT_OF_TOLERANCE");
        }
    }

    private static boolean equal(String a, String b) {
        return MessageDigest.isEqual(a.getBytes(StandardCharsets.UTF_8), b.getBytes(StandardCharsets.UTF_8));
    }

    private static byte[] concat(byte[] a, byte[] b) {
        byte[] out = new byte[a.length + b.length];
        System.arraycopy(a, 0, out, 0, a.length);
        System.arraycopy(b, 0, out, a.length, b.length);
        return out;
    }

    private static String b64(byte[] raw) {
        return Base64.getEncoder().encodeToString(raw);
    }

    private static byte[] sha256(byte[] raw) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(raw);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }

    private static String hmac(String secret, byte[] message) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return b64(mac.doFinal(message));
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }
}
