package ca.superroute.slocker;

import java.util.Map;

/** A verified webhook: partner_locker.* or carrier_package.distribution.* */
public final class WebhookEvent {
    public final String eventId;
    public final String eventType;
    public final boolean livemode;
    public final boolean test;
    public final String occurredAt;
    public final Map<String, Object> data;
    public final Map<String, Object> payload;
    public final String deliveryId;
    public final String keyId;
    /** Lower-case header names. */
    public final Map<String, String> headers;

    WebhookEvent(String eventId, String eventType, boolean livemode, boolean test, String occurredAt, Map<String, Object> data,
                 Map<String, Object> payload, String deliveryId, String keyId, Map<String, String> headers) {
        this.eventId = eventId;
        this.eventType = eventType;
        this.livemode = livemode;
        this.test = test;
        this.occurredAt = occurredAt;
        this.data = data;
        this.payload = payload;
        this.deliveryId = deliveryId;
        this.keyId = keyId;
        this.headers = headers;
    }
}
