package ca.superroute.slocker.customer;

import ca.superroute.sapp.PartnerClient;
import ca.superroute.sapp.TokenStore;

/**
 * The customer side of sLocker: smart-locker pickups, locker locations, locker storage, the locker shop and locker
 * resale for a service provider's customers, on the sApp core.
 *
 * <pre>{@code
 * SLockerCustomer locker = SLocker.customer("p_acme_parcels", "k3m9q2", "sp_appkey_…", tokenStore);
 * locker.sapp().signInWithIdToken(googleIdToken);
 * Object pickups = locker.api.platformAppPickups();
 *
 * // An app that already has an sApp client shares its sign-in:
 * SLockerCustomer shared = SLocker.customer(sr);
 * }</pre>
 */
public final class SLocker {
    private SLocker() {
    }

    /** A customer client that creates its own sApp connection (memory token store when {@code tokenStore} is null). */
    public static SLockerCustomer customer(String appCode, String clientCode, String appKey, TokenStore tokenStore) {
        PartnerClient.Builder builder = PartnerClient.builder(appCode).clientCode(clientCode).appKey(appKey);
        if (tokenStore != null) builder.tokenStore(tokenStore);
        return customer(builder);
    }

    /** A customer client over an sApp connection built from {@code builder} (base URL, locale, transport, …). */
    public static SLockerCustomer customer(PartnerClient.Builder builder) {
        return new SLockerCustomer(builder.build());
    }

    /** A customer client on an existing sApp client: one sign-in, one token store, one refresh for both. */
    public static SLockerCustomer customer(PartnerClient sapp) {
        return new SLockerCustomer(sapp);
    }
}
