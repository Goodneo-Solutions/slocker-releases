package ca.superroute.slocker.customer;

import ca.superroute.sapp.Operation;
import ca.superroute.sapp.OperationFile;
import ca.superroute.sapp.PartnerClient;
import java.util.List;
import java.util.Map;

/**
 * The smart-locker operations of the partner app surface for one person at one service provider. {@link #api} has one
 * method per operation, under the names sApp 0.2.1 had; every call goes through the sApp client's own pipeline (sign-in,
 * refresh, idempotency keys, retries, {@code SuperrouteException}).
 */
public final class SLockerCustomer {
    /** One method per smart-locker operation. */
    public final LockerApi api;

    private final PartnerClient sapp;

    SLockerCustomer(PartnerClient sapp) {
        if (sapp == null) throw new IllegalArgumentException("sapp is required");
        this.sapp = sapp;
        this.api = new LockerApi(sapp::callOperation);
    }

    /** The sApp client underneath: sign in, sign out, the session, and every other partner operation. */
    public PartnerClient sapp() {
        return sapp;
    }

    /** Any operation described by hand, through the sApp client's pipeline. */
    public Object callOperation(Operation operation, Map<String, Object> params, Map<String, ?> body, List<OperationFile> files) {
        return sapp.callOperation(operation, params, body, files);
    }

    /** {@link #callOperation(Operation, Map, Map, List)} without a body or files. */
    public Object callOperation(Operation operation, Map<String, Object> params) {
        return sapp.callOperation(operation, params);
    }
}
