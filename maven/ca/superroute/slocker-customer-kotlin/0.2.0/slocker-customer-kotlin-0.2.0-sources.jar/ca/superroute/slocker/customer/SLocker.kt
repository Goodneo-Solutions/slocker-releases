package ca.superroute.slocker.customer

import ca.superroute.sapp.DEFAULT_BASE_URL
import ca.superroute.sapp.MemoryTokenStore
import ca.superroute.sapp.Operation
import ca.superroute.sapp.OperationFile
import ca.superroute.sapp.PartnerClient
import ca.superroute.sapp.TokenStore
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/**
 * The customer side of sLocker: smart-locker pickups, locker locations, locker storage, the locker shop and locker
 * resale for a service provider's customers, on the sApp core.
 *
 * ```kotlin
 * val locker = SLocker.customer(appCode = "p_acme_parcels", clientCode = "k3m9q2", appKey = "sp_appkey_…", tokenStore = store)
 * locker.sapp.signInWithIdToken(googleIdToken)
 * val pickups = locker.api.platformAppPickups()
 *
 * // An app that already has an sApp client shares its sign-in:
 * val shared = SLocker.customer(sapp = sr)
 * ```
 */
object SLocker {
    /** A customer client that creates its own sApp connection. */
    fun customer(
        appCode: String,
        clientCode: String? = null,
        appKey: String? = null,
        tokenStore: TokenStore = MemoryTokenStore(),
        baseUrl: String = DEFAULT_BASE_URL,
        locale: String? = null,
        deviceId: String? = null,
    ): SLockerCustomer = SLockerCustomer(
        PartnerClient(appCode = appCode, clientCode = clientCode, appKey = appKey, tokenStore = tokenStore, baseUrl = baseUrl, locale = locale, deviceId = deviceId),
    )

    /** A customer client on an existing sApp client: one sign-in, one token store, one refresh for both. */
    fun customer(sapp: PartnerClient): SLockerCustomer = SLockerCustomer(sapp)
}

/**
 * The smart-locker operations of the partner app surface for one person at one service provider. [api] has one method
 * per operation, under the names sApp 0.2.1 had; every call goes through [sapp]'s own pipeline (sign-in, refresh,
 * idempotency keys, retries, `SuperrouteException`).
 */
class SLockerCustomer internal constructor(
    /** The sApp client underneath: sign in, sign out, the session, and every other partner operation. */
    val sapp: PartnerClient,
) {
    /** One method per smart-locker operation. */
    val api: LockerApi = LockerApi { operation, params, body, files -> sapp.callOperation(operation, params, body, files) }

    /** Any operation described by hand, through the sApp client's pipeline. */
    suspend fun callOperation(
        operation: Operation,
        params: Map<String, Any?> = emptyMap(),
        body: JsonObject? = null,
        files: List<OperationFile> = emptyList(),
    ): JsonElement = sapp.callOperation(operation, params, body, files)
}
