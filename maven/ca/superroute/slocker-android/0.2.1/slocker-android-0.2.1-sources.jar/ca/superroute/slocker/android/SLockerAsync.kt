package ca.superroute.slocker.android

import ca.superroute.slocker.Client
import ca.superroute.slocker.Params
import ca.superroute.slocker.Transport
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

/**
 * sLocker for Kotlin and Android: suspend functions over [Client], run on [dispatcher] (IO by default).
 *
 * ```
 * val sl = SLockerAsync(Client.builder().token(token).providerId(7).transport(OkHttpTransport()).build())
 * val delivery = sl.api.partnerLockerDelivery(deliveryNo = "PLD-01J2XYZ")
 * ```
 */
class SLockerAsync(
    val client: Client,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
) {
    /** One suspend function per operation. */
    val api = SLockerOperations(this)

    /** Runs one operation by name; see [Client.call]. */
    suspend fun call(operation: String, params: Params = Params.create()): Any? =
        withContext(dispatcher) { client.call(operation, params) }

    suspend fun login(email: String, password: String, businessId: Long? = null): Any? =
        withContext(dispatcher) { client.login(email, password, businessId) }

    suspend fun refreshToken(): Any? = withContext(dispatcher) { client.refreshToken() }

    suspend fun rotateToken(gracePeriodMinutes: Int? = null): Any? = withContext(dispatcher) { client.rotateToken(gracePeriodMinutes) }

    suspend fun logout(): Any? = withContext(dispatcher) { client.logout() }
}

/** A [Transport] over OkHttp, the HTTP stack Android apps already carry. */
class OkHttpTransport(private val http: OkHttpClient = OkHttpClient()) : Transport {
    override fun send(request: Transport.Request): Transport.Response {
        val body = request.body?.toRequestBody((request.headers["Content-Type"] ?: "application/json").toMediaType())
        val builder = Request.Builder().url(request.url).method(request.method, body)
        request.headers.forEach { (k, v) -> builder.header(k, v) }
        try {
            http.newCall(builder.build()).execute().use { res ->
                val headers = LinkedHashMap<String, String>()
                res.headers.names().forEach { name -> res.header(name)?.let { headers[name] = it } }
                return Transport.Response(res.code, headers, res.body?.bytes() ?: ByteArray(0))
            }
        } catch (e: IOException) {
            throw e
        }
    }
}
