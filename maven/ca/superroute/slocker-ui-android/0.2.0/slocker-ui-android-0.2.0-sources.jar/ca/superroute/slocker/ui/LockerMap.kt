package ca.superroute.slocker.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import ca.superroute.sapp.ui.Obj
import ca.superroute.sapp.ui.SrEnv
import ca.superroute.sapp.ui.SrPagedList
import ca.superroute.sapp.ui.decimal
import ca.superroute.sapp.ui.obj
import ca.superroute.sapp.ui.superroute
import ca.superroute.sapp.ui.text
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** A point the locker map shows. */
data class SrMapPoint(val id: String, val name: String, val latitude: Double, val longitude: Double)

/** The app's own map, as the locker map uses it (the sApp UI kit reference, §Locker map): the kit never creates or draws a map. */
interface SrMapAdapter {
    /** Shows these points, replacing the ones shown before. */
    suspend fun showPoints(points: List<SrMapPoint>)

    /** Calls [handler] with the id of a tapped point. */
    fun onTap(handler: (id: String) -> Unit)

    /** Fits the map to every point shown. */
    suspend fun fitAll()
}

/**
 * The adapter for an sMap Android map (`ca.superroute.smap.SMap` of the sMap SDK). It only calls the map it is given —
 * `addPoints` the first time and `setData` after, `onTap` and `fitLayer` on layer [layer] — and reaches them by name, so
 * the kit takes no map dependency. Call it on the main thread, as the map's own calls.
 */
class SrSMapAdapter(private val map: Any, private val layer: String = "sr-lockers") : SrMapAdapter {
    private var added = false

    private fun method(name: String, test: (Array<Class<*>>) -> Boolean) =
        map.javaClass.methods.first { it.name == name && test(it.parameterTypes) }

    private fun points(points: List<SrMapPoint>): List<Any> {
        val type = Class.forName("ca.superroute.smap.SMapPoint", true, map.javaClass.classLoader)
        val make = type.getConstructor(Double::class.javaPrimitiveType, Double::class.javaPrimitiveType, Map::class.java)
        return points.map { make.newInstance(it.latitude, it.longitude, mapOf("id" to it.id, "name" to it.name)) }
    }

    override suspend fun showPoints(points: List<SrMapPoint>) {
        val list = points(points)
        if (added) {
            method("setData") { it.size == 2 }.invoke(map, layer, list)
        } else {
            val add = method("addPoints") { it.size == 3 && it[1] == List::class.java }
            add.invoke(map, layer, list, add.parameterTypes[2].getConstructor().newInstance())
            added = true
        }
    }

    override fun onTap(handler: (id: String) -> Unit) {
        val tap: (Map<String, Any?>, Any?) -> Unit = { properties, _ -> handler(properties["id"].text()) }
        method("onTap") { it.size == 2 }.invoke(map, layer, tap)
    }

    override suspend fun fitAll() {
        method("fitLayer") { it.size == 3 }.invoke(map, layer, 40, 15.0)
    }
}

/** The state of [LockerMap] (the sApp UI kit reference, §Locker map). */
class LockerMapState(val env: SrEnv, val latitude: Double?, val longitude: Double?, val map: SrMapAdapter?) {
    private val api = env.locker
    var search by mutableStateOf("")
    var filters by mutableStateOf<Set<String>>(emptySet())
        private set
    var list by mutableStateOf(newList())
        private set
    private var tapHooked = false
    var onSelect: (Obj) -> Unit = {}

    private fun newList(): SrPagedList {
        val text = search.trim().ifEmpty { null }
        val f = filters
        return SrPagedList { page ->
            api.platformAppLockerLocations(
                latitude = latitude, longitude = longitude, search = text,
                pickup = if ("pickup" in f) true else null, returnValue = if ("return" in f) true else null,
                available = if ("available" in f) true else null, page = page, perPage = 20,
            )
        }
    }

    suspend fun reload() {
        list = newList()
        list.reset()
        showOnMap()
    }

    suspend fun toggle(filter: String) {
        filters = if (filter in filters) filters - filter else filters + filter
        reload()
    }

    suspend fun more() {
        list.next()
        showOnMap()
    }

    /** `lockers.status_<status>`, else unknown; the free compartments when `capacity` is given. */
    fun statusLine(location: Obj): String {
        val key = "lockers.status_${(location["status"] ?: "unknown").text()}"
        val status = if (env.strings.has(key)) env.t(key) else env.t("lockers.status_unknown")
        val free = location["capacity"].obj()["available"]
        return listOfNotNull(status, free?.let { env.t("lockers.free", "count" to it) }).joinToString(" · ")
    }

    /** The loaded locations' points, for the app's map. */
    val points: List<SrMapPoint>
        get() = list.items.mapNotNull { l ->
            val lat = l["latitude"].decimal()?.toDouble() ?: return@mapNotNull null
            val lng = l["longitude"].decimal()?.toDouble() ?: return@mapNotNull null
            if (l["latitude"] !is Number || l["longitude"] !is Number) return@mapNotNull null
            SrMapPoint(l["id"].text(), l["name"].text(), lat, lng)
        }

    suspend fun showOnMap() {
        val map = map ?: return
        if (!tapHooked) {
            tapHooked = true
            map.onTap { id -> list.items.firstOrNull { it["id"].text() == id }?.let { onSelect(it) } }
        }
        val points = points
        map.showPoints(points)
        if (points.isNotEmpty()) map.fitAll()
    }
}

/** Lockers near the person, as a list and on the app's map ([map], optional). [onSelect] gets the location. */
@Composable
fun LockerMap(latitude: Double? = null, longitude: Double? = null, map: SrMapAdapter? = null, onSelect: (Obj) -> Unit = {}, modifier: Modifier = Modifier) {
    val s = superroute()
    val state = rememberLoaded(latitude, longitude, map, create = { LockerMapState(it, latitude, longitude, map) }) { reload() }
    state.onSelect = onSelect
    val scope = rememberCoroutineScope()
    var typed by remember(state) { mutableStateOf<String?>(null) }
    LaunchedEffect(typed) {
        if (typed == null) return@LaunchedEffect
        delay(400)
        state.reload()
    }
    val list = state.list
    Column(modifier.fillMaxSize()) {
        OutlinedTextField(
            value = state.search, onValueChange = { state.search = it; typed = it }, singleLine = true,
            placeholder = { Text(s.t("lockers.search")) }, label = { Text(s.t("lockers.search")) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { typed = null; scope.launch { state.reload() } }),
            modifier = Modifier.fillMaxWidth().padding(s.space("m")).testTag("sr-lockers-search"),
        )
        Column(Modifier.padding(horizontal = s.space("m"))) {
            SrChips(
                listOf("pickup" to s.t("lockers.filter_pickup"), "return" to s.t("lockers.filter_return"), "available" to s.t("lockers.filter_available")),
                { it in state.filters }, "sr-lockers-filter",
            ) { scope.launch { state.toggle(it) } }
        }
        SrStateView(list.loading, list.error, list.items.isEmpty(), s.t("lockers.empty"), { scope.launch { state.reload() } }) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list.items) { l ->
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onSelect(l) }.padding(horizontal = s.space("l"), vertical = s.space("s"))
                            .testTag("sr-locker-${l["id"].text()}"),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            SrBody(l["name"].text())
                            val address = listOf(l["address"].text(), l["city"].text()).filter { it.isNotEmpty() }.joinToString(", ")
                            if (address.isNotEmpty()) SrMuted(address, small = true)
                            SrMuted(state.statusLine(l), small = true)
                        }
                        if (l["distance_km"] != null) SrBody(s.t("lockers.distance", "km" to l["distance_km"]))
                    }
                    HorizontalDivider()
                }
                item {
                    if (list.hasMore && list.items.isNotEmpty()) SrTextButton(s.t("common.load_more"), "sr-load-more") { scope.launch { state.more() } }
                }
            }
        }
    }
}
