package ca.superroute.slocker.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import ca.superroute.sapp.Operation
import ca.superroute.sapp.OperationAuth
import ca.superroute.sapp.OperationBody
import ca.superroute.sapp.ui.Obj
import ca.superroute.sapp.ui.SrEnv
import ca.superroute.sapp.ui.SrPagedList
import ca.superroute.sapp.ui.decimal
import ca.superroute.sapp.ui.obj
import ca.superroute.sapp.ui.superroute
import ca.superroute.sapp.ui.plain
import ca.superroute.sapp.ui.text
import ca.superroute.sapp.ui.toJson
import kotlinx.serialization.json.JsonElement
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** A point the locker map shows. [kind] is `locker` or `counter` (a pickup point counter); `locker` when the source does not say. */
data class SrMapPoint(val id: String, val name: String, val latitude: Double, val longitude: Double, val kind: String = "locker")

/** What one page of the locker map asks for: the origin, the search and the filters (null = no filter). */
data class LockerMapQuery(
    val latitude: Double?,
    val longitude: Double?,
    val search: String?,
    val pickup: Boolean?,
    val returnValue: Boolean?,
    val available: Boolean?,
    val page: Long,
    val perPage: Long,
)

/** One page from the app's own loader. */
data class LockerMapPage(val items: List<Obj>, val hasMore: Boolean) {
    companion object {
        /** A page from an API answer (`{"data": {"items", "pagination": {"has_more"}}}`). */
        fun of(answer: JsonElement): LockerMapPage {
            val data = answer.plain().obj()["data"].obj()
            @Suppress("UNCHECKED_CAST")
            val items = (data["items"] as? List<*>)?.mapNotNull { it as? Map<String, Any?> } ?: emptyList()
            return LockerMapPage(items, data["pagination"].obj()["has_more"] == true)
        }
    }
}

/** Where the locker map reads its places from. */
sealed interface LockerMapSource {
    /** The signed-in person's lockers (`platformAppLockerLocations`), as before. */
    data object Lockers : LockerMapSource

    /**
     * The service provider's lockers and pickup point counters, read without signing in on the app key
     * (`GET /app/v1/clients/{clientCode}/guest/pickup-points`, the sWidget pickup point picker's read).
     */
    data object PickupPoints : LockerMapSource

    /** The app's own loader. */
    class Custom(val loader: suspend (LockerMapQuery) -> LockerMapPage) : LockerMapSource
}

/** The guest pickup point read, described by hand: the sApp core published as 0.2.2 has no generated method for it. */
internal val GUEST_PICKUP_POINTS = Operation(
    method = "GET", path = "/app/v1/clients/{clientCode}/guest/pickup-points", auth = OperationAuth.KEY,
    query = listOf("latitude", "longitude", "search", "pickup", "return", "available", "page", "per_page"), body = OperationBody.NONE,
)

/** A position on the map. */
data class LockerPosition(val latitude: Double, val longitude: Double)

/** The place the person chose: a smart locker or a pickup point counter. */
data class LockerSelection(
    /** `locker` or `counter`. */
    val kind: String,
    val id: String,
    /** The location's own id (`location_id`, else `id`). */
    val locationId: String,
    val name: String,
    /** Address, city, province and postcode, joined with ", ". */
    val address: String,
    val position: LockerPosition?,
    /** The row as the source answered it. */
    val location: Obj,
) {
    companion object {
        fun of(row: Obj): LockerSelection {
            val lat = row["latitude"] as? Number
            val lng = row["longitude"] as? Number
            return LockerSelection(
                kind = if (row["kind"] == "counter") "counter" else "locker",
                id = row["id"].text(),
                locationId = (row["location_id"] ?: row["id"]).text(),
                name = row["name"].text(),
                address = listOf("address", "city", "province", "postcode").map { row[it].text() }.filter { it.isNotEmpty() }.joinToString(", "),
                position = if (lat != null && lng != null) LockerPosition(lat.toDouble(), lng.toDouble()) else null,
                location = row,
            )
        }
    }
}

/** sLocker's own strings, for keys the sApp kit it builds on (0.2.2) does not have; every other key is sApp's. */
object SlStrings {
    /** Language code → key → text, in the kit's 14 languages. */
    val tables: Map<String, Map<String, String>> = mapOf(
        "en" to ("Smart locker" to "Pickup point"), "chs" to ("智能柜" to "自提点"), "cht" to ("智慧櫃" to "自取點"),
        "de" to ("Smart Locker" to "Abholstelle"), "es" to ("Casillero inteligente" to "Punto de recogida"),
        "fr" to ("Casier intelligent" to "Point de retrait"), "it" to ("Armadietto intelligente" to "Punto di ritiro"),
        "nl" to ("Slimme kluis" to "Afhaalpunt"), "pt" to ("Cacifo inteligente" to "Ponto de recolha"),
        "sr" to ("Pametni ormarić" to "Mesto preuzimanja"), "hu" to ("Okos csomagautomata" to "Átvételi pont"),
        "pl" to ("Inteligentna skrytka" to "Punkt odbioru"), "sk" to ("Inteligentná schránka" to "Výdajné miesto"),
        "cs" to ("Chytrá schránka" to "Výdejní místo"),
    ).mapValues { (_, v) -> mapOf("lockers.kind_locker" to v.first, "lockers.kind_counter" to v.second) }

    /** The text for [key] in [language] (English when the language has none), or null when the key is not sLocker's. */
    fun text(key: String, language: String): String? = tables[language]?.get(key) ?: tables["en"]?.get(key)
}

/** The string for [key]: sLocker's own when it has one, else the sApp kit's. */
internal fun SrEnv.slT(key: String): String = SlStrings.text(key, language) ?: t(key)

/** The app's own map, as the locker map uses it (the sApp UI kit reference, §Locker map): the kit never creates or draws a map. */
interface SrMapAdapter {
    /** Shows these points, replacing the ones shown before. */
    suspend fun showPoints(points: List<SrMapPoint>)

    /** Calls [handler] with the id of a tapped point. */
    fun onTap(handler: (id: String) -> Unit)

    /** Fits the map to every point shown. */
    suspend fun fitAll()
}

/**
 * The adapter for an sMap Android map (`ca.superroute.smap.SMap` of the sMap SDK). It only calls the map it is given —
 * `addPoints` the first time and `setData` after, `onTap` and `fitLayer` on layer [layer] — and reaches them by name, so
 * the kit takes no map dependency. Call it on the main thread, as the map's own calls.
 */
class SrSMapAdapter(private val map: Any, private val layer: String = "sr-lockers") : SrMapAdapter {
    private var added = false

    private fun method(name: String, test: (Array<Class<*>>) -> Boolean) =
        map.javaClass.methods.first { it.name == name && test(it.parameterTypes) }

    private fun points(points: List<SrMapPoint>): List<Any> {
        val type = Class.forName("ca.superroute.smap.SMapPoint", true, map.javaClass.classLoader)
        val make = type.getConstructor(Double::class.javaPrimitiveType, Double::class.javaPrimitiveType, Map::class.java)
        return points.map { make.newInstance(it.latitude, it.longitude, mapOf("id" to it.id, "name" to it.name, "kind" to it.kind)) }
    }

    override suspend fun showPoints(points: List<SrMapPoint>) {
        val list = points(points)
        if (added) {
            method("setData") { it.size == 2 }.invoke(map, layer, list)
        } else {
            val add = method("addPoints") { it.size == 3 && it[1] == List::class.java }
            add.invoke(map, layer, list, add.parameterTypes[2].getConstructor().newInstance())
            added = true
        }
    }

    override fun onTap(handler: (id: String) -> Unit) {
        val tap: (Map<String, Any?>, Any?) -> Unit = { properties, _ -> handler(properties["id"].text()) }
        method("onTap") { it.size == 2 }.invoke(map, layer, tap)
    }

    override suspend fun fitAll() {
        method("fitLayer") { it.size == 3 }.invoke(map, layer, 40, 15.0)
    }
}

/** The state of [LockerMap] (the sApp UI kit reference, §Locker map). */
class LockerMapState(
    val env: SrEnv,
    val latitude: Double?,
    val longitude: Double?,
    val map: SrMapAdapter?,
    val source: LockerMapSource = LockerMapSource.Lockers,
) {
    private val api = env.locker
    var search by mutableStateOf("")
    var filters by mutableStateOf<Set<String>>(emptySet())
        private set
    var list by mutableStateOf(newList())
        private set
    private var tapHooked = false
    var onSelect: (Obj) -> Unit = {}

    /** The typed choice (kind, id, name, address, position), raised beside [onSelect]. */
    var onSelection: (LockerSelection) -> Unit = {}

    /** Raises both select callbacks for a row. */
    fun select(location: Obj) {
        onSelect(location)
        onSelection(LockerSelection.of(location))
    }

    /** The row's kind label (smart locker or pickup point), shown when the source can answer counters. */
    fun kindLabel(location: Obj): String? {
        if (source == LockerMapSource.Lockers) return null
        return env.slT(if (LockerSelection.of(location).kind == "counter") "lockers.kind_counter" else "lockers.kind_locker")
    }

    private fun newList(): SrPagedList {
        val text = search.trim().ifEmpty { null }
        val f = filters
        val source = source
        return SrPagedList { page ->
            val query = LockerMapQuery(
                latitude, longitude, text, if ("pickup" in f) true else null, if ("return" in f) true else null,
                if ("available" in f) true else null, page, 20,
            )
            when (source) {
                is LockerMapSource.Custom -> {
                    val answer = source.loader(query)
                    mapOf("result" to true, "data" to mapOf("items" to answer.items, "pagination" to mapOf("has_more" to answer.hasMore))).toJson()
                }
                LockerMapSource.PickupPoints -> env.client.callOperation(
                    GUEST_PICKUP_POINTS,
                    mapOf(
                        "latitude" to query.latitude, "longitude" to query.longitude, "search" to query.search, "pickup" to query.pickup,
                        "return" to query.returnValue, "available" to query.available, "page" to query.page, "per_page" to query.perPage,
                    ),
                )
                LockerMapSource.Lockers -> api.platformAppLockerLocations(
                latitude = latitude, longitude = longitude, search = text,
                pickup = if ("pickup" in f) true else null, returnValue = if ("return" in f) true else null,
                available = if ("available" in f) true else null, page = page, perPage = 20,
            )
            }
        }
    }

    suspend fun reload() {
        list = newList()
        list.reset()
        showOnMap()
    }

    suspend fun toggle(filter: String) {
        filters = if (filter in filters) filters - filter else filters + filter
        reload()
    }

    suspend fun more() {
        list.next()
        showOnMap()
    }

    /** `lockers.status_<status>`, else unknown; the free compartments when `capacity` is given. */
    fun statusLine(location: Obj): String {
        val key = "lockers.status_${(location["status"] ?: "unknown").text()}"
        val status = if (env.strings.has(key)) env.t(key) else env.t("lockers.status_unknown")
        val free = location["capacity"].obj()["available"]
        return listOfNotNull(kindLabel(location), status, free?.let { env.t("lockers.free", "count" to it) }).joinToString(" · ")
    }

    /** The loaded locations' points, for the app's map. */
    val points: List<SrMapPoint>
        get() = list.items.mapNotNull { l ->
            val lat = l["latitude"].decimal()?.toDouble() ?: return@mapNotNull null
            val lng = l["longitude"].decimal()?.toDouble() ?: return@mapNotNull null
            if (l["latitude"] !is Number || l["longitude"] !is Number) return@mapNotNull null
            SrMapPoint(l["id"].text(), l["name"].text(), lat, lng, LockerSelection.of(l).kind)
        }

    suspend fun showOnMap() {
        val map = map ?: return
        if (!tapHooked) {
            tapHooked = true
            map.onTap { id -> list.items.firstOrNull { it["id"].text() == id }?.let { select(it) } }
        }
        val points = points
        map.showPoints(points)
        if (points.isNotEmpty()) map.fitAll()
    }
}

/**
 * Lockers near the person, as a list and on the app's map ([map], optional). [source] says where the places come from
 * (the person's lockers by default). [onSelect] gets the location; [onSelection] the typed choice.
 */
@Composable
fun LockerMap(
    latitude: Double? = null,
    longitude: Double? = null,
    map: SrMapAdapter? = null,
    onSelect: (Obj) -> Unit = {},
    modifier: Modifier = Modifier,
    source: LockerMapSource = LockerMapSource.Lockers,
    onSelection: (LockerSelection) -> Unit = {},
) {
    val s = superroute()
    val state = rememberLoaded(latitude, longitude, map, source, create = { LockerMapState(it, latitude, longitude, map, source) }) { reload() }
    state.onSelect = onSelect
    state.onSelection = onSelection
    val scope = rememberCoroutineScope()
    var typed by remember(state) { mutableStateOf<String?>(null) }
    LaunchedEffect(typed) {
        if (typed == null) return@LaunchedEffect
        delay(400)
        state.reload()
    }
    val list = state.list
    Column(modifier.fillMaxSize()) {
        OutlinedTextField(
            value = state.search, onValueChange = { state.search = it; typed = it }, singleLine = true,
            placeholder = { Text(s.t("lockers.search")) }, label = { Text(s.t("lockers.search")) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { typed = null; scope.launch { state.reload() } }),
            modifier = Modifier.fillMaxWidth().padding(s.space("m")).testTag("sr-lockers-search"),
        )
        Column(Modifier.padding(horizontal = s.space("m"))) {
            SrChips(
                listOf("pickup" to s.t("lockers.filter_pickup"), "return" to s.t("lockers.filter_return"), "available" to s.t("lockers.filter_available")),
                { it in state.filters }, "sr-lockers-filter",
            ) { scope.launch { state.toggle(it) } }
        }
        SrStateView(list.loading, list.error, list.items.isEmpty(), s.t("lockers.empty"), { scope.launch { state.reload() } }) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list.items) { l ->
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { state.select(l) }.padding(horizontal = s.space("l"), vertical = s.space("s"))
                            .testTag("sr-locker-${l["id"].text()}"),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            SrBody(l["name"].text())
                            val address = listOf(l["address"].text(), l["city"].text()).filter { it.isNotEmpty() }.joinToString(", ")
                            if (address.isNotEmpty()) SrMuted(address, small = true)
                            SrMuted(state.statusLine(l), small = true)
                        }
                        if (l["distance_km"] != null) SrBody(s.t("lockers.distance", "km" to l["distance_km"]))
                    }
                    HorizontalDivider()
                }
                item {
                    if (list.hasMore && list.items.isNotEmpty()) SrTextButton(s.t("common.load_more"), "sr-load-more") { scope.launch { state.more() } }
                }
            }
        }
    }
}
