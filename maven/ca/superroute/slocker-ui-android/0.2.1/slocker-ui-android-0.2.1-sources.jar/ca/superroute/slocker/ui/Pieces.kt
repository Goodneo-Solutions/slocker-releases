package ca.superroute.slocker.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import ca.superroute.sapp.ui.SrEnv
import ca.superroute.sapp.ui.SrPagedList
import ca.superroute.sapp.ui.SrScope
import ca.superroute.sapp.ui.superroute
import ca.superroute.slocker.customer.LockerApi
import ca.superroute.slocker.customer.SLocker
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

// The pieces these components share with the sApp Compose kit. The kit keeps its own internal; these follow them, so
// the sLocker components look and behave as the kit's.

/** The smart-locker operations for the scope's client (one sign-in with the sApp kit). */
val SrEnv.locker: LockerApi get() = SLocker.customer(sapp = client).api

/** Rethrows cancellation; answers every other failure. */
internal inline fun <T> attempt(block: () -> T): Result<T> = try {
    Result.success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Throwable) {
    Result.failure(e)
}

/** A state holder kept for one client and loaded when it is first shown and whenever the client changes. */
@Composable
internal fun <T : Any> rememberLoaded(vararg keys: Any?, create: (SrEnv) -> T, load: suspend T.() -> Unit): T {
    val env = superroute().env
    val state = remember(env, *keys) { create(env) }
    LaunchedEffect(state) { state.load() }
    return state
}

@Composable
internal fun SrMuted(text: String, modifier: Modifier = Modifier, small: Boolean = false) {
    val s = superroute()
    Text(text, modifier = modifier, color = s.color("muted"), fontSize = if (small) s.size("small") else s.size("body"))
}

@Composable
internal fun SrBody(text: String, modifier: Modifier = Modifier) {
    val s = superroute()
    Text(text, modifier = modifier, fontSize = s.size("body"), color = s.color("onSurface"))
}

/** A text the component shows after an action (a success or a refusal). */
@Composable
internal fun SrNotice(text: String?, tag: String) {
    if (text.isNullOrEmpty()) return
    val s = superroute()
    Text(text, modifier = Modifier.fillMaxWidth().padding(vertical = s.space("s")).testTag(tag), color = s.color("onSurface"), fontSize = s.size("body"))
}

@Composable
internal fun SrPrimaryButton(text: String, tag: String, enabled: Boolean = true, modifier: Modifier = Modifier.fillMaxWidth(), onClick: () -> Unit) {
    val s = superroute()
    Button(
        onClick = onClick, enabled = enabled,
        modifier = modifier.heightIn(min = 48.dp).testTag(tag),
        shape = RoundedCornerShape(s.radius("medium")),
        colors = ButtonDefaults.buttonColors(containerColor = s.color("primary"), contentColor = s.color("onPrimary")),
    ) { Text(text) }
}

@Composable
internal fun SrTextButton(text: String, tag: String, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = 44.dp).testTag(tag)) { Text(text) }
}

/** The loading / error / empty frame every list shares. */
@Composable
internal fun SrStateView(loading: Boolean, error: Throwable?, empty: Boolean, emptyText: String, onRetry: () -> Unit, content: @Composable () -> Unit) {
    val s = superroute()
    when {
        loading && empty -> Box(Modifier.fillMaxWidth().padding(s.space("l")), contentAlignment = Alignment.Center) {
            val label = s.t("common.loading")
            CircularProgressIndicator(Modifier.semantics { contentDescription = label }.testTag("sr-loading"))
        }
        error != null && empty -> Column(Modifier.fillMaxWidth().padding(s.space("l")), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(s.env.errorText(error), modifier = Modifier.testTag("sr-error"), textAlign = TextAlign.Center, color = s.color("onSurface"), fontSize = s.size("body"))
            Spacer(Modifier.padding(s.space("s")))
            OutlinedButton(onClick = onRetry, modifier = Modifier.heightIn(min = 48.dp).testTag("sr-retry"), shape = RoundedCornerShape(s.radius("medium"))) {
                Text(s.t("common.retry"))
            }
        }
        empty -> Box(Modifier.fillMaxWidth().padding(s.space("l")), contentAlignment = Alignment.Center) {
            Text(emptyText, modifier = Modifier.testTag("sr-empty"), color = s.color("muted"), fontSize = s.size("body"))
        }
        else -> content()
    }
}

/** **Load more** while the list has more pages. */
@Composable
internal fun SrLoadMore(list: SrPagedList) {
    if (!list.hasMore || list.items.isEmpty()) return
    val s = superroute()
    val scope = rememberCoroutineScope()
    SrTextButton(s.t("common.load_more"), "sr-load-more", enabled = !list.loading) { scope.launch { list.next() } }
}

/** Chips of which any number may be chosen. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun SrChips(options: List<Pair<String, String>>, selected: (String) -> Boolean, tag: String, onToggle: (String) -> Unit) {
    val s = superroute()
    FlowRow(horizontalArrangement = Arrangement.spacedBy(s.space("xs")), modifier = Modifier.fillMaxWidth()) {
        options.forEach { (key, label) ->
            FilterChip(selected = selected(key), onClick = { onToggle(key) }, label = { Text(label) }, modifier = Modifier.heightIn(min = 44.dp).testTag("$tag-$key"))
        }
    }
}

/** A pending confirmation: a text, the confirm label and what runs when confirmed. */
internal class SrAsk(val text: String, val confirm: String, val tag: String, val run: suspend () -> Unit)

/** Shows [ask] while it is set: the confirm button first (left), Cancel second (right). */
@Composable
internal fun SrAskDialog(ask: SrAsk?, scope: CoroutineScope, onClose: () -> Unit) {
    if (ask == null) return
    val s = superroute()
    AlertDialog(
        onDismissRequest = onClose,
        text = { Text(ask.text, fontSize = s.size("body"), modifier = Modifier.testTag("sr-dialog-text")) },
        confirmButton = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { onClose(); scope.launch { ask.run() } }, modifier = Modifier.heightIn(min = 44.dp).testTag(ask.tag),
                    colors = ButtonDefaults.buttonColors(containerColor = s.color("primary"), contentColor = s.color("onPrimary"))) { Text(ask.confirm) }
                Spacer(Modifier.width(s.space("s")))
                TextButton(onClick = onClose, modifier = Modifier.heightIn(min = 44.dp).testTag("sr-dialog-cancel")) { Text(s.t("common.cancel")) }
            }
        },
    )
}

/** The common text style of large figures. */
internal fun SrScope.figureStyle() = TextStyle(fontSize = size("title"), fontWeight = FontWeight.SemiBold, color = color("onSurface"))
