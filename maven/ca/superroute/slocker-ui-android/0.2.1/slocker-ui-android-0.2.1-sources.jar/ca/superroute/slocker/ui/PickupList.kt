package ca.superroute.slocker.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import ca.superroute.sapp.ui.Obj
import ca.superroute.sapp.ui.SrEnv
import ca.superroute.sapp.ui.SrPagedList
import ca.superroute.sapp.ui.body
import ca.superroute.sapp.ui.isTrue
import ca.superroute.sapp.ui.long
import ca.superroute.sapp.ui.obj
import ca.superroute.sapp.ui.superroute
import ca.superroute.sapp.ui.text
import kotlinx.coroutines.launch

/** The state of [PickupList] (the sApp UI kit reference, §Pickup list). */
class PickupListState(val env: SrEnv) {
    private val api = env.locker
    var list by mutableStateOf(newList())
        private set
    val opening = mutableStateListOf<String>()
    var message by mutableStateOf<String?>(null)
        private set

    private fun newList() = SrPagedList { page -> api.platformAppPickups(page = page, perPage = 20) }

    suspend fun reload() {
        list = newList()
        list.reset()
    }

    /** The confirmation text for opening the door at a pickup's location. */
    fun confirmText(pickup: Obj): String = env.t("pickups.collect_confirm", "location" to pickup["location"].obj()["name"].text())

    /** Opens the door (after the person confirmed); success shows `pickups.opened` and reloads. */
    suspend fun collect(pickup: Obj) {
        val id = pickup["id"].text()
        opening.add(id)
        message = null
        attempt { api.platformAppCollectPickup(pickup["id"].long() ?: 0, body("user_confirmed" to true)) }
            .onSuccess {
                message = env.t("pickups.opened")
                reload()
            }
            .onFailure { message = env.errorText(it) }
        opening.remove(id)
    }
}

/** Parcels waiting in lockers, their pickup codes and opening the door. [onShowCode] gets the QR value for the app's QR view. */
@Composable
fun PickupList(onShowCode: (qrValue: String) -> Unit = {}, modifier: Modifier = Modifier) {
    val s = superroute()
    val state = rememberLoaded(create = ::PickupListState) { reload() }
    val scope = rememberCoroutineScope()
    var ask by remember { mutableStateOf<SrAsk?>(null) }
    val list = state.list
    SrAskDialog(ask, scope) { ask = null }
    Column(modifier.fillMaxSize()) {
        SrNotice(state.message, "sr-pickup-message")
        SrStateView(list.loading, list.error, list.items.isEmpty(), s.t("pickups.empty"), { scope.launch { state.reload() } }) {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = s.space("l")), verticalArrangement = Arrangement.spacedBy(s.space("m"))) {
                items(list.items) { p ->
                    val id = p["id"].text()
                    val location = p["location"].obj()
                    Card(Modifier.fillMaxWidth().testTag("sr-pickup-$id"), shape = RoundedCornerShape(s.radius("large"))) {
                        Column(Modifier.padding(s.space("l"))) {
                            Text(location["name"].text(), style = s.figureStyle())
                            if (location["address"] != null) SrMuted(location["address"].text())
                            Spacer(Modifier.height(s.space("m")))
                            SrMuted(s.t("pickups.code"), small = true)
                            Text(
                                p["pickup_code"].text(),
                                modifier = Modifier.clickable { onShowCode((p["pickup_qr_value"] ?: p["pickup_code"]).text()) }.testTag("sr-pickup-code-$id"),
                                fontSize = (s.theme.type["headline"] ?: 26.0).plus(6).sp, fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold, letterSpacing = 4.sp, color = s.color("onSurface"),
                            )
                            Spacer(Modifier.height(s.space("s")))
                            SrBody(s.t("pickups.remaining", "count" to (p["remaining_count"] ?: 0)))
                            if (p["expires_at"] != null) SrBody(s.t("pickups.expires", "date" to s.date(p["expires_at"])))
                            if (p["remote_open_available"].isTrue()) {
                                Spacer(Modifier.height(s.space("m")))
                                SrPrimaryButton(s.t("pickups.collect"), "sr-pickup-open-$id", enabled = id !in state.opening) {
                                    ask = SrAsk(state.confirmText(p), s.t("pickups.collect"), "sr-pickup-confirm") { state.collect(p) }
                                }
                            }
                        }
                    }
                }
                item { SrLoadMore(list) }
            }
        }
    }
}
